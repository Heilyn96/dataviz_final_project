# Data Visualization 

> Heilyn Gonzalez. 

## Mini-Project 2

After selecting  multiple dataset, I finally wanted to work with Bad Drivers in U.S. I did not know that some of the finding in this projects would be true, for example:

- Speeding drivers are less involved in fatal collisions comparing with alcohol-impaired. Maybe, that is the result of high tickets if a Police Officer caught you speeding but when you are drunk you do not think in that or in the fatal consequences of driving in that condition. 

-Distracted drivers are the second type of bad drivers involved in fatal accidents in the U.s.

-I was surprised that Florida is not in the top 5 of bad drivers, I really do not want to move to one of those cities like South Carolina. 

For plotting the data I wanted to use barplots with each of types of bad drivers and I tried to get them in one page, unfortunately I got to do it but the graphs did not look presentable. 

I got some issues with R, the program was presenting some error and one of them was about the version of R and because of that I couldn't run the packages for getting interactive plots. After i got the version that it showed me, the program could run the codes, it shows this error: "the path is too long". I used sf(), plotly(), leaflet(), and so on. Neither of them got different result. Adding to that, I am finishing this project using a monitor because my computer screen doesn't show anything when I have R running. 